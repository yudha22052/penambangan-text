# !pip install flask Sastrawi nlpaug tensorflow scikit-learn imbalanced-learn requests beautifulsoup4

from flask import Flask, request, jsonify, render_template
import re
import pickle
import pandas as pd
import nltk
from nltk.corpus import stopwords
from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
import nlpaug.augmenter.word as naw
import tensorflow as tf
import requests
from bs4 import BeautifulSoup
import numpy as np

# Download NLTK resources
nltk.download('stopwords')
nltk.download('wordnet')
nltk.download('punkt')
nltk.download('averaged_perceptron_tagger_eng')

app = Flask(__name__)

# Load model and vectorizer
with open('models/tfidf_vectorizer_cnn.sav', 'rb') as f:
    vectorizer = pickle.load(f)
model = tf.keras.models.load_model('models/cnn_model.keras')

# Label encoder classes
label_encoder_classes = ['ADVERTORIAL', 'AGRI', 'BOLA', 'CEK FAKTA', 'EDUKASI', 'FOOD', 'GLOBAL', 'HEALTH',
                        'HOMEY', 'HYPE', 'IKN', 'KATANETIZEN', 'LESTARI', 'LIFESTYLE', 'MONEY', 'NEWS',
                        'OTOMOTIF', 'PROPERTI', 'REGIONAL', 'SAINS', 'SKOLA', 'STORI', 'TEKNO',
                        'TRAVEL', 'TREN', 'UMKM']

# Preprocessing functions
def clean_lower(lwr):
    lwr = lwr.lower()
    return lwr

def clean_punct(text):
    clean_spcl = re.compile('[/(){}\|@,;_]')
    clean_symbol = re.compile('[^0-9a-z]')
    clean_number = re.compile('[0-9]')
    text = clean_spcl.sub('', text)
    text = clean_symbol.sub(' ', text)
    text = clean_number.sub('', text)
    return text

def _normalize_whitespace(text):
    corrected = str(text)
    corrected = re.sub(r"//t", r"\t", corrected)
    corrected = re.sub(r"( )\1+", r"\1", corrected)
    corrected = re.sub(r"(\n)\1+", r"\1", corrected)
    corrected = re.sub(r"(\r)\1+", r"\1", corrected)
    corrected = re.sub(r"(\t)\1+", r"\1", corrected)
    return corrected.strip(" ")

def clean_stopwords(text):
    stopword = set(stopwords.words('indonesian'))
    text = ' '.join(word for word in text.split() if word not in stopword)
    return text

def sastrawistemmer(text):
    factory = StemmerFactory()
    st = factory.create_stemmer()
    text = ' '.join([st.stem(word) for word in text.split()])
    return text


def augment_text(text, augmenter):
    augmented_text = augmenter.augment(text)
    if isinstance(augmented_text, list):
        augmented_text = ' '.join(augmented_text)

    augmented_text = re.sub(r'[^\w\s]', '', augmented_text)  # Membersihkan karakter aneh
    augmented_text = _normalize_whitespace(augmented_text)   # Normalisasi whitespace

    return augmented_text


def predict_category(text):
    text = clean_lower(text)
    text = clean_punct(text)
    text = _normalize_whitespace(text)
    text = clean_stopwords(text)
    text = sastrawistemmer(text)


    aug_sr = naw.SynonymAug(aug_src='wordnet')
    text_aug_sr = augment_text(text, aug_sr)
    aug_ri = naw.RandomWordAug(aug_min=1, aug_max=10)
    text_aug_ri = augment_text(text, aug_ri)


    text_combined = f"{text} {' '.join(text_aug_sr)} {' '.join(text_aug_ri)}"



    text_vec = vectorizer.transform([text_combined]).toarray()
    text_padded = text_vec.reshape(text_vec.shape[0], text_vec.shape[1], 1)

    prediction = model.predict(text_padded)
    predicted_label = np.argmax(prediction, axis=1)[0]


    try:
        predicted_category = label_encoder_classes[predicted_label]
    except IndexError:
        predicted_category = "Kategori tidak diketahui"
    return predicted_category


@app.route("/", methods=['GET', 'POST'])
def index():
    predicted_category = None
    article_title = None
    if request.method == 'POST':
        link = request.form.get('link')
        try:
            response = requests.get(link)
            response.raise_for_status()
            soup = BeautifulSoup(response.content, 'html.parser')

            title_tag = soup.find('title')
            if title_tag:
                article_title = title_tag.text.strip()

            article_content = " ".join([p.text for p in soup.find_all('p')])
            predicted_category = predict_category(article_content)

        except requests.exceptions.RequestException as e:
            predicted_category = f"Error fetching URL: {e}"
        except Exception as e:
            predicted_category = f"An error occurred: {e}"

    return render_template('index.html', predicted_category=predicted_category, article_title=article_title)

if __name__ == '__main__':
    app.run(debug=True)